<?php 
$mod_strings = Array(
	'LBL_CATEGORYS_INFORMATION' => '基本信息',
	'Category Name' => '分类名称',
	'Sequence' => '排序',
	'Categoryicon'=>'分类图标',
);
?>