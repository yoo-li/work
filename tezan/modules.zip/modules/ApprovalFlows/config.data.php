<?php

$tabid  = '129';
$tabname  = 'ApprovalFlows';

$config_tabs =  array (  
				    'tabid' => '129',
					'tabname' => 'ApprovalFlows',
					'tablabel' => 'ApprovalFlows',
				    'presence' => '0',
				    'customized' => '0',
				    'isentitytype' => '0',
				    'tabsequence' => '129',
				    'ownedby' => '0',
					);

$Config_Blocks = array (
	  1 => array (	    
	    'blocklabel' => 'LBL_APPROVALFLOWS_INFORMATION',
	    'sequence' => '1',
	    'show_title' => '0',
	    'visible' => '0',
	    'create_view' => '0',
	    'edit_view' => '0',
	    'detail_view' => '0',
	    'display_status' => '1',
	    'iscustom' => '0',
	  ),	 
	  
);


$Config_Fields = array (
   
   array (
    'generatedtype' => '1',
    'uitype' => '222',
    'fieldname' => 'tabid',
    'fieldlabel' => 'tabname',
    'readonly' => '0',
    'presence' => '0',
    'maximumlength' => '100',
    'sequence' => '2',
    'block' => '1',
    'displaytype' => '1',
    'typeofdata' => 'V~M',
    'info_type' => 'BAS',
    'merge_column' => '0',
    'deputy_column' => '0',
    'show_title' => '1',
	'width' => '12', // 4,8,12,20,30
	'align' => 'center', // left,center,right
	'relation' => 'fieldname',
  ),  
 
   array (
    'generatedtype' => '1',
    'uitype' => '56',
    'fieldname' => 'approvalflowsstatus',
    'fieldlabel' => 'ApprovalFlows Status',
    'readonly' => '0',
    'presence' => '2',
    'maximumlength' => '50',
    'sequence' => '5',
    'block' => '1',
    'displaytype' => '1',
    'typeofdata' => 'V~M',
    'info_type' => 'BAS',
    'merge_column' => '0',
    'deputy_column' => '0',
    'show_title' => '1',
	'width' => '12', // 4,8,12,20,30
	'align' => 'center', // left,center,right
  ),
  array (
    'generatedtype' => '1',
    'uitype' => '56',
    'fieldname' => 'mark',
    'fieldlabel' => 'ApprovalFlows Mark',
    'readonly' => '0',
    'presence' => '2',
    'maximumlength' => '50',
    'sequence' => '3',
    'block' => '1',
    'displaytype' => '2',
    'typeofdata' => 'V~O',
    'info_type' => 'BAS',
    'merge_column' => '0',
    'deputy_column' => '0',
    'show_title' => '1',
	'width' => '12', // 4,8,12,20,30
	'align' => 'center', // left,center,right
  ),
  
  array (
    'generatedtype' => '1',
    'uitype' => '100',
    'fieldname' => 'fieldname',
    'fieldlabel' => 'Amount FieldName',
    'readonly' => '0',
    'presence' => '0',
    'maximumlength' => '100',
    'sequence' => '3',
    'block' => '1',
    'displaytype' => '1',
    'typeofdata' => 'V~O',
    'info_type' => 'BAS',
    'merge_column' => '0',
    'deputy_column' => '0',
    'show_title' => '1',
	'width' => '12', // 4,8,12,20,30
	'align' => 'left', // left,center,right
  ), 
   array (
    'generatedtype' => '1',
    'uitype' => '1',
    'fieldname' => 'flowdata',
    'fieldlabel' => 'flowdata',
    'readonly' => '0',
    'presence' => '2',
    'maximumlength' => '99999',
    'sequence' => '6',
    'block' => '1',
    'displaytype' => '2',
    'typeofdata' => 'V~O',
    'info_type' => 'BAS',
    'merge_column' => '0',
    'deputy_column' => '0',
    'show_title' => '1',
	'width' => '12', // 4,8,12,20,30
	'align' => 'left', // left,center,right
  ),
 array (
    'generatedtype' => '1',
    'uitype' => '15',
    'fieldname' => 'approvalflowstype',
    'fieldlabel' => 'ApprovalFlows Type',
    'readonly' => '0',
    'presence' => '2',
    'maximumlength' => '50',
    'sequence' => '7',
    'block' => '1',
    'displaytype' => '2',
    'typeofdata' => 'V~M',
    'info_type' => 'BAS',
    'merge_column' => '0',
    'deputy_column' => '0',
    'show_title' => '1',
	'width' => '12', // 4,8,12,20,30
	'align' => 'center', // left,center,right
  ),
   
  array (
    'generatedtype' => '1',
    'uitype' => '56',
    'fieldname' => 'approvaldetails',
    'fieldlabel' => 'Approval Details',
    'readonly' => '0',
    'presence' => '2',
    'maximumlength' => '50',
    'sequence' => '11',
    'block' => '1',
    'displaytype' => '1',
    'typeofdata' => 'V~O',
    'info_type' => 'BAS',
    'merge_column' => '0',
    'deputy_column' => '0',
    'show_title' => '1',
	'width' => '12', // 4,8,12,20,30
	'align' => 'center', // left,center,right
  ),
  array (
    'generatedtype' => '1',
    'uitype' => '56',
    'fieldname' => 'revokeapprovalaftermodify',
    'fieldlabel' => 'Revoke Approval After Modify',
    'readonly' => '0',
    'presence' => '2',
    'maximumlength' => '50',
    'sequence' => '12',
    'block' => '1',
    'displaytype' => '1',
    'typeofdata' => 'V~O',
    'info_type' => 'BAS',
    'merge_column' => '0',
    'deputy_column' => '0',
    'show_title' => '1',
    'width' => '12', // 4,8,12,20,30
    'align' => 'center', // left,center,right
  ), 
   array (
    'generatedtype' => '1',
    'uitype' => '19',
    'fieldname' => 'description',
    'fieldlabel' => 'Description',
    'readonly' => '0',
    'presence' => '2',
    'maximumlength' => '100',
    'sequence' => '20',
    'block' => '1',
    'displaytype' => '1',
    'typeofdata' => 'V~O',
    'info_type' => 'BAS',
    'merge_column' => '0',
    'deputy_column' => '0',
    'show_title' => '1',
	'width' => '12', // 4,8,12,20,30
	'align' => 'left', // left,center,right
	'editwidth' => '80%',  
    'merge_column' => '1',
  ),
  );
  
$Config_CustomViews = array (
1 => 
  array (
    'viewname' => 'Default',
    'setdefault' => '1',
    'setmetrics' => '0',
    'entitytype' => 'approvalflows',
    'status' => '0',
    'cvcolumnlist' => 
    array (   
	   'tabid','fieldname','preapproval','buttonname','approvalflowsstatus', 'approvalflowstype', 'published','oper'
    ),
  ), 
);  

$Config_Ws_Entitys = array (
  1 => 
  array (
    'name' => 'ApprovalFlows',
    'handler_path' => 'include/Webservices/VtigerModuleOperation.php',
    'handler_class' => 'VtigerModuleOperation',
    'ismodule' => '1',
  ),
);

$Config_Entitynames = array (
  0 => 
  array (   
    'modulename' => 'ApprovalFlows',
    'tablename' => 'approvalflows',
    'fieldname' => 'approvalflows_no',
    'entityidfield' => 'xn_id',
    'entityidcolumn' => 'xn_id',
  ),
);

$config_modentity_nums = array ( );



$config_picklists = array (
  array (
		    'name' => 'approvalflowstype',
		    'picklist' => 
					   array (
							  0 => 
							  array (
								0 => 'SYSTEM',
								1 => '1',
								2 => '1',
							  ),
							  1 => 
							  array (
								0 => 'USER',
								1 => '2',
								2 => '2',
							  ),
							 					 
		  	  		 ),
	   ),
);



?>