<?php

$mod_strings = Array(
'LBL_MODLEINFO'=>'审批流程',
'LBL_SETTINGS'=>'设置',
'LBL_MODLE_DESCRIPTION'=>'待审批的记录(我审批，我送审)',


'LBL_APPROVALFLOWS_INFORMATION'=>'基本信息',
'ApprovalFlows'=>'审批流程',
'description' => '描述',
'status' => '状态',
'published' => '建立时间',
'type' => '类型',
'Description' => '描述',

'ApprovalFlows Status' => '启用',
'tabname' => '模块名称',
'ApprovalFlow No' => '编号',
'ApprovalFlows Type' => '类型',
'SYSTEM' => '系统',
'USER' => '用户定制',
'Amount FieldName' => '金额字段', 
'Revoke Approval After Modify' => '修改提交后撤销所有审批',
'Approval Details' => '审批明细',
'Notification Information'  => '审批信息',
'LBL_DELETE_SYSTEM_APPROVALFLOWS' => '类型为"系统"的审批流程是不允许删除，但可以设置不启用！',
'LBL_APPROVALFLOWS_MODIFYFLOWS'  => '当前审批流程修改，所有的审批被退回，需要重新提交审批！',
'LBL_APPROVALFLOWS_NOSAVE' => '自动结束<font color=red>%1</font>提交的审批请求，<font color=red>%2</font>模块需要重新提交审批！',

);


?>