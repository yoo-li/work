<?php 
$mod_strings = Array(
	'LBL_BASE_INFORMATION' => '基本信息',
	'LBL_SEARCHTITLE' => '请输入物流名称或网站',
	'LBL_EXPRESS_INFORMATION' => '物流单据信息',
	'Logistics No' => '物流ID',
	'Logistics Name' => '物流公司简称',
	'Telphone' => '查询电话',
	'Site' => '查询网站',
    'supplierLogisticInfo'=>'物流配置信息',
    'LogisticsExpress'=>'',
	'Sequence' => '排序',
);
?>