<?php 
$mod_strings = Array(
	'LBL_BASE_INFORMATION' => '基本信息', 
	'BillWaters No' => '流水ID',
	'UserName' => '用户',
	'SupplierID' => '商家名称', 
	'Bill Water Type' => '流水类型',
	'Share Date' => '分享时间',
	'Amount' => '金額',
	'Money' => '当前余额',
	'Share ID' => '分享',
	'Order ID' => '订单', 
    'Product ID' => '商品',
	'Commission Type' => '提成处理状态',
	'Royalty Rate' => '提成比率',
	'Submit DateTime' => '创建时间',
	'UserName' => '用户',
	'Invite Profileid' => '被邀请人',
	'Invite Profile' => '被邀请会员',
	'Middle Invite Profile' => '中间会员',
);
?>