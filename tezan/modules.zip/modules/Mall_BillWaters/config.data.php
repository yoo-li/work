<?php

$tabid  = '3018';
$tabname  = 'Mall_BillWaters';

$config_tabs =  array (  	 			    
					'tabname' => 'Mall_BillWaters',
					'tablabel' => 'Mall_BillWaters',
				    'presence' => '0',
				    'customized' => '0',
				    'isentitytype' => '1',
				    'tabsequence' => '3018',
				    'ownedby' => '0',
					);

$Config_Blocks = array (
	  1 => array (	    
	    'blocklabel' => 'LBL_BASE_INFORMATION',
	    'sequence' => '1',
	    'show_title' => '0',
	    'visible' => '0',
	    'create_view' => '0',
	    'edit_view' => '0',
	    'detail_view' => '0',
	    'display_status' => '1',
	    'iscustom' => '0',
		'columns' =>  '2',
	  ), 
);


$Config_Fields = array (
array (
    'generatedtype' => '2',
    'uitype' => '10',
    'fieldname' => 'supplierid',
    'fieldlabel' => 'SupplierID',
    'readonly' => '1',
    'presence' => '2',
    'maximumlength' => '100',
    'sequence' => '1',
    'block' => '1',
    'displaytype' => '2',
    'typeofdata' => 'V~O',
    'info_type' => 'BAS',
    'merge_column' => '1',
    'deputy_column' => '0',
    'show_title' => '1',
    'editwidth' => '300',
    'width' => '12', // 4,8,12,20,30
    'align' => 'center', // left,center,right
),
  array(
      'generatedtype' => '1',
      'uitype' => '54',
      'fieldname' => 'profileid',
      'fieldlabel' => 'UserName',
      'readonly' => '0',
      'presence' => '0',
      'maximumlength' => '50',
      'sequence' => '2',
      'block' => '1',
      'displaytype' => '1',
      'typeofdata' => 'V~M',
      'info_type' => 'BAS',
      'merge_column' => '1',
      'deputy_column' => '0',
      'show_title' => '1',
      'width' => '8', // 4,8,12,20,30
      'align' => 'center', // left,center,right
  ),
   array(
      'generatedtype' => '1',
      'uitype' => '33',
      'fieldname' => 'billwatertype',
      'fieldlabel' => 'Bill Water Type',
      'readonly' => '0',
      'presence' => '0',
      'maximumlength' => '50',
      'sequence' => '7',
      'block' => '1',
      'displaytype' => '1',
      'typeofdata' => 'V~M',
      'info_type' => 'BAS',
      'merge_column' => '1',
      'deputy_column' => '0',
      'show_title' => '1',
      'width' => '8', // 4,8,12,20,30
      'align' => 'center', // left,center,right
  ),
 array (
	'generatedtype' => '1',
	'uitype' => '5',
	'fieldname' => 'sharedate',
	'fieldlabel' => 'Share Date',
	'readonly' => '0',
	'presence' => '2',
	'maximumlength' => '100',
	'sequence' => '3',
	'block' => '1',
	'displaytype' => '1',
	'typeofdata' => 'D~M',
	'info_type' => 'BAS',
	'merge_column' => '1',
	'deputy_column' => '0',
	'show_title' => '1',
	'width' => '8', // 4,8,12,20,30
	'align' => 'center', // left,center,right
  ), 
  array(
      'generatedtype' => '1',
      'uitype' => '1',
      'fieldname' => 'amount',
      'fieldlabel' => 'Amount',
      'readonly' => '0',
      'presence' => '0',
      'maximumlength' => '50',
      'sequence' => '4',
      'block' => '1',
      'displaytype' => '1',
      'typeofdata' => 'NN~M~10,2',
      'info_type' => 'BAS',
      'merge_column' => '1',
      'deputy_column' => '0',
      'show_title' => '1',
      'width' => '8', // 4,8,12,20,30
      'align' => 'center', // left,center,right
  ),
   array(
      'generatedtype' => '1',
      'uitype' => '1',
      'fieldname' => 'money',
      'fieldlabel' => 'Money',
      'readonly' => '0',
      'presence' => '0',
      'maximumlength' => '50',
      'sequence' => '4',
      'block' => '1',
      'displaytype' => '1',
      'typeofdata' => 'NN~M~10,2',
      'info_type' => 'BAS',
      'merge_column' => '1',
      'deputy_column' => '0',
      'show_title' => '1',
      'width' => '8', // 4,8,12,20,30
      'align' => 'center', // left,center,right
  ),
  array(
      'generatedtype' => '1',
      'uitype' => '10',
      'fieldname' => 'shareid',
      'fieldlabel' => 'Share ID',
      'readonly' => '0',
      'presence' => '0',
      'maximumlength' => '50',
      'sequence' => '4',
      'block' => '1',
      'displaytype' => '1',
      'typeofdata' => 'NN~M~10,2',
      'info_type' => 'BAS',
      'merge_column' => '1',
      'deputy_column' => '0',
      'show_title' => '1',
      'width' => '8', // 4,8,12,20,30
      'align' => 'center', // left,center,right
  ),   
  array(
        'generatedtype' => '1',
        'uitype' => '10',
        'fieldname' => 'productid',
        'fieldlabel' => 'Product ID',
        'readonly' => '0',
        'presence' => '0',
        'maximumlength' => '50',
        'sequence' => '4',
        'block' => '1',
        'displaytype' => '1',
        'typeofdata' => 'NN~M~10,2',
        'info_type' => 'BAS',
        'merge_column' => '1',
        'deputy_column' => '0',
        'show_title' => '1',
        'width' => '8', // 4,8,12,20,30
        'align' => 'center', // left,center,right
    ), 
    array(
        'generatedtype' => '1',
        'uitype' => '10',
        'fieldname' => 'orderid',
        'fieldlabel' => 'Order ID',
        'readonly' => '0',
        'presence' => '0',
        'maximumlength' => '50',
        'sequence' => '4',
        'block' => '1',
        'displaytype' => '1',
        'typeofdata' => 'NN~M~10,2',
        'info_type' => 'BAS',
        'merge_column' => '1',
        'deputy_column' => '0',
        'show_title' => '1',
        'width' => '8', // 4,8,12,20,30
        'align' => 'center', // left,center,right
    ), 
   array(
      'generatedtype' => '1',
      'uitype' => '54',
      'fieldname' => 'inviteprofileid',
      'fieldlabel' => 'Invite Profileid',
      'readonly' => '0',
      'presence' => '0',
      'maximumlength' => '50',
      'sequence' => '8',
      'block' => '1',
      'displaytype' => '1',
      'typeofdata' => 'V~M',
      'info_type' => 'BAS',
      'merge_column' => '1',
      'deputy_column' => '0',
      'show_title' => '1',
      'width' => '8', // 4,8,12,20,30
      'align' => 'center', // left,center,right
  ), 
);

$Config_CustomViews = array (
  array (
	'viewname' => 'Default',
	'setdefault' => '1',
	'setmetrics' => '0',
	'entitytype' => 'Mall_BillWaters',
	'status' => '0',
	'cvcolumnlist' => array ('supplierid','profileid','billwatertype','sharedate','amount','money','inviteprofileid','shareid','productid','orderid','published'),
  ), 
);  

$Config_Ws_Entitys = array (
  1 => 
  array (
    'name' => 'Mall_BillWaters',
    'handler_path' => 'include/Webservices/VtigerModuleOperation.php',
    'handler_class' => 'VtigerModuleOperation',
    'ismodule' => '1',
  ),
);

$Config_Entitynames = array (
  0 => 
  array (   
    'modulename' => 'Mall_BillWaters',
    'tablename' => 'Mall_BillWaters',
    'fieldname' => 'billwaters_no',
    'entityidfield' => 'xn_id',
    'entityidcolumn' => 'xn_id',
  ),
);


$config_fieldmodulerels = array (  
   array (
		 'fieldname' => 'orderid',
		 'module' => 'Mall_BillWaters',
		 'relmodule' => 'Mall_Orders',
		 'status' => '',
		 'sequence' => '0',
	  ), 
    array (
		 'fieldname' => 'shareid',
		 'module' => 'Mall_BillWaters',
		 'relmodule' => 'Mall_Shares',
		 'status' => '',
		 'sequence' => '0',
	  ), 
	array (
		 'fieldname' => 'productid',
		 'module' => 'Mall_BillWaters',
		 'relmodule' => 'Mall_Products',
		 'status' => '',
		 'sequence' => '0',
	  ),
    array (
        'fieldname' => 'supplierid',
        'module' => 'Mall_BillWaters',
        'relmodule' => 'Suppliers',
        'status' => '',
        'sequence' => '0',
    )
);

$config_modentity_nums = array ( );

$config_searchcolumn = array(
	array(
		'sequence' => '1',
		'columnname' => 'published',
		'fieldname' => 'published',
		'fieldlabel' => 'Create Date',
		'type' => 'calendar',
		'info_type' => 'BAS',
		'newline' => false,
	),
	array(
		'sequence' => '2',
		'columnname' => 'billwatertype',
		'fieldname' => 'billwatertype',
		'fieldlabel' => 'Bill Water Type',
		'type' => 'text',
		'info_type' => 'BAS',
		'newline' => false,
	), 
  

);
 
$config_picklists = array ( 
array (
		'name' => 'billwatertype',
		'picklist' => 
		array (
		  0 =>   array ( 0 => '分享收益', 1 => '0', 2 => 'share', ),
		  1 =>   array ( 0 => '提成收益', 1 => '1', 2 => 'commission', ),
		  2 =>   array ( 0 => '广告收益', 1 => '2', 2 => 'ad', ), 
		  3 =>   array ( 0 => '公益支出', 1 => '3', 2 => 'publicinterest', ),
		  4 =>   array ( 0 => '消费支出', 1 => '4', 2 => 'consumption', ),
		  5 =>   array ( 0 => '推广收益', 1 => '5', 2 => 'popularize', ),
		  6 =>   array ( 0 => '会员管理', 1 => '6', 2 => 'profile', ),
		  7 =>   array ( 0 => '余额退款', 1 => '7', 2 => 'reimburse', ),
		  8 =>   array ( 0 => '退货减提成', 1 => '8', 2 => 'deductpercentage', ),
		  9=>	 array ( 0 => '退货减基金',1=>'9',2=>'returnsharefund'),
		  10=>	 array ( 0 => '扣除推广收益',1=>'10',2=>'deductpopularize'),
		  14=>	 array ( 0 => '会员充值',1=>'14',2=>'addprofile'), 
		  15=>	 array ( 0 => '会员反充值',1=>'15',2=>'decprofile'), 
		  16=>	 array ( 0 => '提现',1=>'16',2=>'takecash'), 
		  17=>	 array ( 0 => '驳回提现',1=>'17',2=>'rejecttakecash'), 
		  18=>	 array ( 0 => '新会员福利',1=>'18',2=>'newprofilebenefit'), 
		  19=>	 array ( 0 => '签到收益',1=>'18',2=>'reception'), 
		  20=>	 array ( 0 => '签到佣金',1=>'18',2=>'receptioncommission'), 
		   
		),
	  ),
array (
		'name' => 'commissiontype',
		'picklist' => 
		array (
		  1 =>   array ( 0 => '冻结', 1 => '1', 2 => '0', ),
		  2 =>   array ( 0 => '已结算', 1 => '2', 2 => '1', ),  
		 
		),
	  ),	  
 );

?>

