<?php 
$mod_strings = Array(
    'LBL_BASE_INFORMATION' => '基本信息', 
    'APP Name'=>'推送应用名称',
	'Push Product'=>'产品关键字',
	'DeviceType'=>'适用设备', 
	'Deploy Status'=>'部署状态', 
);
?>