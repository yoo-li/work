<?php 
$mod_strings = Array(
	'LBL_BASE_INFORMATION' => '基本信息', 
	'Supplier'=>'商家',
	'Profile'=>'申请人',
	'Account'=>'真实姓名',
	'Department'=>'部门',
	'Email'=>'邮件',
	'Mall_OfficialApplys Status'=>'状态',
     
);
?>