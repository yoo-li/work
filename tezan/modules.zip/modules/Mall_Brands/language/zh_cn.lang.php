<?php 
$mod_strings = Array(
    'SupplierID'=>'商家名称',
    'LBL_BASE_INFORMATION' => '基本信息',
    'LBL_SEARCHSUPPLIER'=>'名称、用户名或手机号',
    'LBL_SEARCHTITLE' => '请输入品牌名称关键字',
    'Brands No' => '品牌ID',
    'Brand Name' => '品牌名称', 
    'Brand Logo' => '品牌LOGO',
    'Brandlogo' => '品牌LOGO',
    'Site Url' => '品牌网址',
    'Sort Order' => '排序',
    'Is show' => '是否显示',
    'Brand Desc' => '品牌描述',
    'Mall_Brands Status'=>'审批状态',
    'Certificate' => '品牌证书',
    'Submit Approv Alreply time'=>'审批时间',
	'Recommendation' => '推荐首页',
    'Data From'=>'来源',
    'Status'=>'启用状态'
);
?>