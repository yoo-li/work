<?php

$tabid  = '115';
$tabname  = 'Approvals';

$config_tabs =  array (  	 			    
					'tabname' => 'Approvals',
					'tablabel' => 'Approvals',
				    'presence' => '0',
				    'customized' => '0',
				    'isentitytype' => '1',
				    'tabsequence' => '115',
				    'ownedby' => '0',
					);

$Config_Blocks = array (
	  1 => array (	    
	    'blocklabel' => 'LBL_APPROVALS_INFORMATION',
	    'sequence' => '1',
	    'show_title' => '0',
	    'visible' => '0',
	    'create_view' => '0',
	    'edit_view' => '0',
	    'detail_view' => '0',
	    'display_status' => '1',
	    'iscustom' => '0',
	  ),	 
	  
);


$Config_Fields = array ( 
   array (
    'generatedtype' => '1',
    'uitype' => '222',
    'fieldname' => 'tabid',
    'fieldlabel' => 'Tabname',
    'readonly' => '0',
    'presence' => '0',
    'maximumlength' => '100',
    'sequence' => '2',
    'block' => '1',
    'displaytype' => '1',
    'typeofdata' => 'V~M',
    'info_type' => 'BAS',
    'merge_column' => '0',
    'deputy_column' => '0',
    'show_title' => '1',
	'width' => '8', // 4,8,12,20,30
	'align' => 'left', // left,center,right
  ), 

   array (
    'generatedtype' => '1',
    'uitype' => '1',
    'fieldname' => 'finished',
    'fieldlabel' => 'Finished',
    'readonly' => '0',
    'presence' => '0',
    'maximumlength' => '100',
    'sequence' => '3',
    'block' => '1',
    'displaytype' => '1',
    'typeofdata' => 'V~M',
    'info_type' => 'BAS',
    'merge_column' => '0',
    'deputy_column' => '0',
    'show_title' => '1',
	'width' => '12', // 4,8,12,20,30
	'align' => 'left', // left,center,right
  ), 
  array (
    'generatedtype' => '1',
    'uitype' => '1',
    'fieldname' => 'flowid',
    'fieldlabel' => 'Flowid',
    'readonly' => '0',
    'presence' => '0',
    'maximumlength' => '100',
    'sequence' => '4',
    'block' => '1',
    'displaytype' => '1',
    'typeofdata' => 'V~M',
    'info_type' => 'BAS',
    'merge_column' => '0',
    'deputy_column' => '0',
    'show_title' => '1',
	'width' => '12', // 4,8,12,20,30
	'align' => 'left', // left,center,right
  ), 
    array (
    'generatedtype' => '1',
    'uitype' => '1',
    'fieldname' => 'nextflowid',
    'fieldlabel' => 'Nextflowid',
    'readonly' => '0',
    'presence' => '0',
    'maximumlength' => '100',
    'sequence' => '5',
    'block' => '1',
    'displaytype' => '1',
    'typeofdata' => 'V~M',
    'info_type' => 'BAS',
    'merge_column' => '0',
    'deputy_column' => '0',
    'show_title' => '1',
	'width' => '12', // 4,8,12,20,30
	'align' => 'left', // left,center,right
  ), 
   array (
    'generatedtype' => '1',
    'uitype' => '101',
    'fieldname' => 'userid',
    'fieldlabel' => 'Userid',
    'readonly' => '0',
    'presence' => '0',
    'maximumlength' => '100',
    'sequence' => '6',
    'block' => '1',
    'displaytype' => '1',
    'typeofdata' => 'V~M',
    'info_type' => 'BAS',
    'merge_column' => '0',
    'deputy_column' => '0',
    'show_title' => '1',
	'width' => '8', // 4,8,12,20,30
	'align' => 'center', // left,center,right
  ),
   array (
    'generatedtype' => '1',
    'uitype' => '101',
    'fieldname' => 'proxyapproval',
    'fieldlabel' => 'Proxy Approval',
    'readonly' => '0',
    'presence' => '0',
    'maximumlength' => '100',
    'sequence' => '7',
    'block' => '1',
    'displaytype' => '1',
    'typeofdata' => 'V~O',
    'info_type' => 'BAS',
    'merge_column' => '0',
    'deputy_column' => '0',
    'show_title' => '1',
	'width' => '8', // 4,8,12,20,30
	'align' => 'center', // left,center,right
  ), 
  array (
    'generatedtype' => '1',
    'uitype' => '101',
    'fieldname' => 'approver',
    'fieldlabel' => 'Approver',
    'readonly' => '0',
    'presence' => '0',
    'maximumlength' => '100',
    'sequence' => '7',
    'block' => '1',
    'displaytype' => '1',
    'typeofdata' => 'V~O',
    'info_type' => 'BAS',
    'merge_column' => '0',
    'deputy_column' => '0',
    'show_title' => '1',
	'width' => '8', // 4,8,12,20,30
	'align' => 'center', // left,center,right
  ), 
   array (
    'generatedtype' => '1',
    'uitype' => '101',
    'fieldname' => 'from_userid',
    'fieldlabel' => 'From_userid',
    'readonly' => '0',
    'presence' => '0',
    'maximumlength' => '100',
    'sequence' => '7',
    'block' => '1',
    'displaytype' => '1',
    'typeofdata' => 'V~M',
    'info_type' => 'BAS',
    'merge_column' => '0',
    'deputy_column' => '0',
    'show_title' => '1',
	'width' => '8', // 4,8,12,20,30
	'align' => 'center', // left,center,right
  ), 
   array (
    'generatedtype' => '1',
    'uitype' => '101',
    'fieldname' => 'sourcer',
    'fieldlabel' => 'Sourcer',
    'readonly' => '0',
    'presence' => '0',
    'maximumlength' => '100',
    'sequence' => '7',
    'block' => '1',
    'displaytype' => '2',
    'typeofdata' => 'V~M',
    'info_type' => 'BAS',
    'merge_column' => '0',
    'deputy_column' => '0',
    'show_title' => '1',
	'width' => '8', // 4,8,12,20,30
	'align' => 'center', // left,center,right
  ), 
 
   array (
    'generatedtype' => '1',
    'uitype' => '223',
    'fieldname' => 'record',
    'fieldlabel' => 'Record',
    'readonly' => '0',
    'presence' => '0',
    'maximumlength' => '100',
    'sequence' => '8',
    'block' => '1',
    'displaytype' => '1',
    'typeofdata' => 'V~M',
    'info_type' => 'BAS',
    'merge_column' => '0',
    'deputy_column' => '0',
    'show_title' => '1',
	'width' => '8', // 4,8,12,20,30
	'align' => 'center', // left,center,right
  ), 
   array (
    'generatedtype' => '1',
    'uitype' => '1',
    'fieldname' => 'reply',
    'fieldlabel' => 'Reply',
    'readonly' => '0',
    'presence' => '0',
    'maximumlength' => '100',
    'sequence' => '9',
    'block' => '1',
    'displaytype' => '1',
    'typeofdata' => 'V~M',
    'info_type' => 'BAS',
    'merge_column' => '0',
    'deputy_column' => '0',
    'show_title' => '1',
	'width' => '8', // 4,8,12,20,30
	'align' => 'left', // left,center,right
  ), 
   array (
    'generatedtype' => '1',
    'uitype' => '1',
    'fieldname' => 'reply_text',
    'fieldlabel' => 'Reply_text',
    'readonly' => '0',
    'presence' => '0',
    'maximumlength' => '100',
    'sequence' => '10',
    'block' => '1',
    'displaytype' => '1',
    'typeofdata' => 'V~M',
    'info_type' => 'BAS',
    'merge_column' => '0',
    'deputy_column' => '0',
    'show_title' => '1',
	'width' => '12', // 4,8,12,20,30
	'align' => 'left', // left,center,right
  ),
   array (
    'generatedtype' => '1',
    'uitype' => '5',
    'fieldname' => 'submitapprovalreplydatetime',
    'fieldlabel' => 'Submitreplydatetime',
    'readonly' => '0',
    'presence' => '0',
    'maximumlength' => '100',
    'sequence' => '11',
    'block' => '1',
    'displaytype' => '1',
    'typeofdata' => 'V~O',
    'info_type' => 'BAS',
    'merge_column' => '0',
    'deputy_column' => '0',
    'show_title' => '1',
	'width' => '12', // 4,8,12,20,30
	'align' => 'center', // left,center,right
  ),
  
array (
    'generatedtype' => '1',
    'uitype' => '1',
    'fieldname' => 'guid',
    'fieldlabel' => 'Guid',
    'readonly' => '0',
    'presence' => '2',
    'maximumlength' => '100',
    'sequence' => '12',
    'block' => '1',
    'displaytype' => '2',
    'typeofdata' => 'V~M',
    'info_type' => 'BAS',
    'merge_column' => '0',
    'deputy_column' => '0',
    'show_title' => '1',
	'width' => '12', // 4,8,12,20,30
	'align' => 'left', // left,center,right
    'merge_column' => '0',
  ),
  array (
    'generatedtype' => '1',
    'uitype' => '1',
    'fieldname' => 'approvalflows',
    'fieldlabel' => 'approvalflows',
    'readonly' => '0',
    'presence' => '2',
    'maximumlength' => '100',
    'sequence' => '13',
    'block' => '1',
    'displaytype' => '2',
    'typeofdata' => 'V~O',
    'info_type' => 'BAS',
    'merge_column' => '0',
    'deputy_column' => '0',
    'show_title' => '1',
	'width' => '12', // 4,8,12,20,30
	'align' => 'left', // left,center,right
    'merge_column' => '0',
  ),
  array (
    'generatedtype' => '1',
    'uitype' => '115',
    'fieldname' => 'approvaltype',
    'fieldlabel' => 'Type',
    'readonly' => '0',
    'presence' => '2',
    'maximumlength' => '100',
    'sequence' => '13',
    'block' => '1',
    'displaytype' => '2',
    'typeofdata' => 'V~O',
    'info_type' => 'BAS',
    'merge_column' => '0',
    'deputy_column' => '0',
    'show_title' => '1',
	'width' => '8', // 4,8,12,20,30
	'align' => 'left', // left,center,right
    'merge_column' => '0',
  ),
  array (
    'generatedtype' => '1',
    'uitype' => '19',
    'fieldname' => 'description',
    'fieldlabel' => 'Description',
    'readonly' => '0',
    'presence' => '2',
    'maximumlength' => '100',
    'sequence' => '20',
    'block' => '1',
    'displaytype' => '1',
    'typeofdata' => 'V~M',
    'info_type' => 'BAS',
    'deputy_column' => '0',
    'show_title' => '1',
	'width' => '12', // 4,8,12,20,30
	'align' => 'left', // left,center,right
    'merge_column' => '1',
  ),
  array (
    'generatedtype' => '1',
    'uitype' => '236',
    'fieldname' => 'personman',
    'fieldlabel' => 'Assigned To',
    'readonly' => '0',
    'presence' => '0',
    'maximumlength' => '100',
    'sequence' => '9',
    'block' => '1',
    'displaytype' => '2',
    'typeofdata' => 'V~O',
    'info_type' => 'BAS',
    'merge_column' => '0',
    'deputy_column' => '0',
    'show_title' => '1',
	'width' => '12', // 4,8,12,20,30
	'align' => 'left', // left,center,right
  ),
  array (
    'generatedtype' => '1',
    'uitype' => '7',
    'fieldname' => 'amount',
    'fieldlabel' => 'Amount',
    'readonly' => '0',
    'presence' => '0',
    'maximumlength' => '100',
    'sequence' => '19',
    'block' => '1',
    'displaytype' => '2',
    'typeofdata' => 'V~O',
    'info_type' => 'BAS',
    'merge_column' => '0',
    'deputy_column' => '0',
    'show_title' => '1',
	'width' => '12', // 4,8,12,20,30
	'align' => 'left', // left,center,right
  ),
   array (
    'generatedtype' => '1',
    'uitype' => '7',
    'fieldname' => 'decideapproval',
    'fieldlabel' => 'DecideApproval',
    'readonly' => '0',
    'presence' => '0',
    'maximumlength' => '100',
    'sequence' => '19',
    'block' => '1',
    'displaytype' => '2',
    'typeofdata' => 'V~O',
    'info_type' => 'BAS',
    'merge_column' => '0',
    'deputy_column' => '0',
    'show_title' => '1',
	'width' => '12', // 4,8,12,20,30
	'align' => 'left', // left,center,right
  ),
   array (
    'generatedtype' => '1',
    'uitype' => '1',
    'fieldname' => 'approvalinfo',
    'fieldlabel' => 'Notification Information',
    'readonly' => '0',
    'presence' => '0',
    'maximumlength' => '100',
    'sequence' => '20',
    'block' => '1',
    'displaytype' => '2',
    'typeofdata' => 'V~O',
    'info_type' => 'BAS',
    'merge_column' => '0',
    'deputy_column' => '0',
    'show_title' => '1',
	'width' => '20', // 4,8,12,20,30
	'align' => 'left', // left,center,right
  ),
  );

 
$Config_CustomViews = array (
	  array (
		'viewname' => 'Default',
		'setdefault' => '1',
		'setmetrics' => '0',
		'entitytype' => 'approvals',
		'status' => '0',
		'cvcolumnlist' => 
		array ('from_userid','published','userid','approvalinfo','submitapprovalreplydatetime','reply','approvaltype','record'),
	  ), 
	);  

$Config_Ws_Entitys = array (
  1 => 
  array (
    'name' => 'Approvals',
    'handler_path' => 'include/Webservices/VtigerModuleOperation.php',
    'handler_class' => 'VtigerModuleOperation',
    'ismodule' => '1',
  ),
);

$Config_Entitynames = array (
  0 => 
  array (   
    'modulename' => 'Approvals',
    'tablename' => 'Approvals',
    'fieldname' => 'Approvals_no',
    'entityidfield' => 'xn_id',
    'entityidcolumn' => 'xn_id',
  ),
);

$config_modentity_nums = array ( );

$config_searchcolumn = array(
	array(
		'sequence' => '1',
		'columnname' => 'published',
		'fieldname' => 'published',
		'fieldlabel' => 'Create Date',
		'type' => 'calendar',
		'info_type' => 'BAS',
		'newline' => false,
	),
	array(
		'sequence' => '2',
		'columnname' => 'reply',
		'fieldname' => 'reply',
		'fieldlabel' => 'reply',
		'type' => 'text',
		'info_type' => 'BAS',
		'newline' => false,
	),
);


$config_picklists = array (
	array (
		'name' => 'approvaltype',
		'picklist' => 
		array(
			array ('Self','1','1'),
			array ('Proxy','1','2'),
			array ('Timeout','1','3'),
		),
	),
	
);

?>

