<?php

$tabid  = '128';
$tabname  = 'ApprovalCenters';

$config_tabs =  array (  	 			    
					'tabname' => 'ApprovalCenters',
					'tablabel' => 'ApprovalCenters',
				    'presence' => '0',
				    'customized' => '0',
				    'isentitytype' => '1',
				    'tabsequence' => '128',
				    'ownedby' => '0',
					);

$Config_Blocks = array (
	  1 => array (	    
	    'blocklabel' => 'LBL_BASE_INFORMATION',
	    'sequence' => '1',
	    'show_title' => '0',
	    'visible' => '0',
	    'create_view' => '0',
	    'edit_view' => '0',
	    'detail_view' => '0',
	    'display_status' => '1',
	    'iscustom' => '0',
	  ),	 
	  
);


$Config_Fields = array ( 
   array (
    'generatedtype' => '1',
    'uitype' => '222',
    'fieldname' => 'tabid',
    'fieldlabel' => 'Tabname',
    'readonly' => '0',
    'presence' => '0',
    'maximumlength' => '100',
    'sequence' => '1',
    'block' => '1',
    'displaytype' => '2',
    'typeofdata' => 'V~M',
    'info_type' => 'BAS',
    'merge_column' => '0',
    'deputy_column' => '0',
    'show_title' => '1',
	'width' => '8', // 4,8,12,20,30
	'align' => 'center', // left,center,right
  ), 
  array (
   'generatedtype' => '1',
   'uitype' => '223',
   'fieldname' => 'record',
   'fieldlabel' => 'Record',
   'readonly' => '0',
   'presence' => '0',
   'maximumlength' => '100',
   'sequence' => '2',
   'block' => '1',
   'displaytype' => '2',
   'typeofdata' => 'V~M',
   'info_type' => 'BAS',
   'merge_column' => '0',
   'deputy_column' => '0',
   'show_title' => '1',
	'width' => '8', // 4,8,12,20,30
	'align' => 'center', // left,center,right
 ), 
 array (
   'generatedtype' => '1',
   'uitype' => '1',
   'fieldname' => 'flowid',
   'fieldlabel' => 'Flowid',
   'readonly' => '0',
   'presence' => '0',
   'maximumlength' => '100',
   'sequence' => '3',
    'block' => '1',
    'displaytype' => '2',
    'typeofdata' => 'V~M',
    'info_type' => 'BAS',
    'merge_column' => '0',
    'deputy_column' => '0',
    'show_title' => '1',
	'width' => '12', // 4,8,12,20,30
	'align' => 'center', // left,center,right
 ), 
   array (
    'generatedtype' => '1',
    'uitype' => '15',
    'fieldname' => 'finished',
    'fieldlabel' => 'IsFinished',
    'readonly' => '0',
    'presence' => '0',
    'maximumlength' => '100',
    'sequence' => '4',
    'block' => '1',
    'displaytype' => '2',
    'typeofdata' => 'V~M',
    'info_type' => 'BAS',
    'merge_column' => '0',
    'deputy_column' => '0',
    'show_title' => '1',
	'width' => '12', // 4,8,12,20,30
	'align' => 'center', // left,center,right
  ), 
  
  array (
   'generatedtype' => '1',
   'uitype' => '101',
   'fieldname' => 'sourcer',
   'fieldlabel' => 'Sourcer',
   'readonly' => '0',
   'presence' => '0',
   'maximumlength' => '100',
   'sequence' => '5',
   'block' => '1',
   'displaytype' => '2',
   'typeofdata' => 'V~M',
   'info_type' => 'BAS',
   'merge_column' => '0',
   'deputy_column' => '0',
   'show_title' => '1',
	'width' => '8', // 4,8,12,20,30
	'align' => 'center', // left,center,right
 ), 
 
  array (
    'generatedtype' => '1',
    'uitype' => '101',
    'fieldname' => 'approver',
    'fieldlabel' => 'Approver',
    'readonly' => '0',
    'presence' => '0',
    'maximumlength' => '100',
    'sequence' => '6',
    'block' => '1',
    'displaytype' => '2',
    'typeofdata' => 'V~O',
    'info_type' => 'BAS',
    'merge_column' => '0',
    'deputy_column' => '0',
    'show_title' => '1',
	'width' => '12', // 4,8,12,20,30
	'align' => 'center', // left,center,right
  ), 
  array (
    'generatedtype' => '1',
    'uitype' => '101',
    'fieldname' => 'pendingapprover',
    'fieldlabel' => 'Pending Approver',
    'readonly' => '0',
    'presence' => '0',
    'maximumlength' => '100',
    'sequence' => '6',
    'block' => '1',
    'displaytype' => '2',
    'typeofdata' => 'V~O',
    'info_type' => 'BAS',
    'merge_column' => '0',
    'deputy_column' => '0',
    'show_title' => '1',
	'width' => '12', // 4,8,12,20,30
	'align' => 'center', // left,center,right
  ), 
  array (
    'generatedtype' => '1',
    'uitype' => '6',
    'fieldname' => 'lastapprovaldatetime',
    'fieldlabel' => 'Last Approval Datetime',
    'readonly' => '0',
    'presence' => '0',
    'maximumlength' => '100',
    'sequence' => '7',
    'block' => '1',
    'displaytype' => '2',
	'typeofdata' => 'DT~O',
    'info_type' => 'BAS',
    'merge_column' => '0',
    'deputy_column' => '0',
    'show_title' => '1',
	'width' => '12', // 4,8,12,20,30
	'align' => 'center', // left,center,right
  ),   
  array (
    'generatedtype' => '1',
    'uitype' => '101',
    'fieldname' => 'finishapprover',
    'fieldlabel' => 'Finish Approver',
    'readonly' => '0',
    'presence' => '0',
    'maximumlength' => '100',
    'sequence' => '8',
    'block' => '1',
    'displaytype' => '2',
    'typeofdata' => 'V~O',
    'info_type' => 'BAS',
    'merge_column' => '0',
    'deputy_column' => '0',
    'show_title' => '1',
 	'width' => '8', // 4,8,12,20,30
 	'align' => 'center', // left,center,right
  ),  
  array (
    'generatedtype' => '1',
    'uitype' => '6',
    'fieldname' => 'finishapprovaldatetime',
    'fieldlabel' => 'Finish Approval Datetime',
    'readonly' => '0',
    'presence' => '0',
    'maximumlength' => '100',
    'sequence' => '9',
    'block' => '1',
    'displaytype' => '2',
	'typeofdata' => 'DT~O',
    'info_type' => 'BAS',
    'merge_column' => '0',
    'deputy_column' => '0',
    'show_title' => '1',
	'width' => '12', // 4,8,12,20,30
	'align' => 'center', // left,center,right
  ),   
  array (
    'generatedtype' => '1',
    'uitype' => '7',
    'fieldname' => 'amount',
    'fieldlabel' => 'Amount',
    'readonly' => '0',
    'presence' => '0',
    'maximumlength' => '100',
    'sequence' => '10',
    'block' => '1',
    'displaytype' => '2',
    'typeofdata' => 'V~O',
    'info_type' => 'BAS',
    'merge_column' => '0',
    'deputy_column' => '0',
    'show_title' => '1',
	'width' => '8', // 4,8,12,20,30
	'align' => 'center', // left,center,right
  ),
  array (
    'generatedtype' => '1',
    'uitype' => '7',
    'fieldname' => 'approvalstatus',
    'fieldlabel' => 'Approval Status',
    'readonly' => '0',
    'presence' => '0',
    'maximumlength' => '100',
    'sequence' => '11',
    'block' => '1',
    'displaytype' => '2',
    'typeofdata' => 'V~O',
    'info_type' => 'BAS',
    'merge_column' => '0',
    'deputy_column' => '0',
    'show_title' => '1',
	'width' => '12', // 4,8,12,20,30
	'align' => 'center', // left,center,right
  ),
  array (
    'generatedtype' => '1',
    'uitype' => '7',
    'fieldname' => 'approvalcentersstatus',
    'fieldlabel' => 'ApprovalCenters status',
    'readonly' => '0',
    'presence' => '0',
    'maximumlength' => '100',
    'sequence' => '12',
    'block' => '1',
    'displaytype' => '2',
    'typeofdata' => 'V~O',
    'info_type' => 'BAS',
    'merge_column' => '0',
    'deputy_column' => '0',
    'show_title' => '1',
	'width' => '12', // 4,8,12,20,30
	'align' => 'center', // left,center,right
  ),
 
);

 
$Config_CustomViews = array (
	  array (
		'viewname' => 'Default',
		'setdefault' => '1',
		'setmetrics' => '0',
		'entitytype' => 'approvalcenters',
		'status' => '0',
		'cvcolumnlist' => 
		array ('tabid','sourcer','published','approver','lastapprovaldatetime','pendingapprover','finished','finishapprover','finishapprovaldatetime','amount','approvalcentersstatus','record'),
	  ), 
	);  

$Config_Ws_Entitys = array (
  1 => 
  array (
    'name' => 'ApprovalCenters',
    'handler_path' => 'include/Webservices/VtigerModuleOperation.php',
    'handler_class' => 'VtigerModuleOperation',
    'ismodule' => '1',
  ),
);

$Config_Entitynames = array (
  0 => 
  array (   
    'modulename' => 'ApprovalCenters',
    'tablename' => 'ApprovalCenters',
    'fieldname' => 'ApprovalCenters_no',
    'entityidfield' => 'xn_id',
    'entityidcolumn' => 'xn_id',
  ),
);

$config_modentity_nums = array ( );

$config_searchcolumn = array(
	array(
		'sequence' => '1',
		'columnname' => 'published',
		'fieldname' => 'published',
		'fieldlabel' => 'Create Date',
		'type' => 'calendar',
		'info_type' => 'BAS',
		'newline' => false,
	),
	array(
		'sequence' => '2',
		'columnname' => 'approvalstatus',
		'fieldname' => 'approvalstatus',
		'fieldlabel' => 'Approval Status',
		'type' => 'text',
		'info_type' => 'BAS',
		'newline' => false,
	),
);


$config_picklists = array (
	array (
		'name' => 'approvalstatus',
		'picklist' => 
		array(
			array ('Approvaling','1','1'),
			array ('Agree','1','2'),
			array ('Disagree','1','3'),
		),
	),
	array (
		'name' => 'finished',
		'picklist' =>
			array(
				array ('Finished','1','true'),
				array ('Running','1','false'),
			),
	),
);

?>

