<?php

$mod_strings = Array(
'Planned consume time'=>'计划耗时',
'Description'=>'备注',
'Not implemented'=>'未执行',
'Implementation'=>'执行中',
'Has been executed'=>'已执行',
'Terminate'=>'已终止',
'Implementation status'=>'执行状态',
'Archive'=>'已存档',
'Cancel'=>'取消',
'Telephone'=>'电话',
'E-Mail'=>'邮件',
'Drop in'=>'上门',
'Visit'=>'来访',
'Entertain'=>'招待',
'Inspect'=>'参观',
'Shuttle'=>'接送',
'Other'=>'其它',
'Calendar no'=>'待办ID',
'Do theme'=>'待办主题',
'Do class'=>'待办类型',
'Account name'=>'客户简称',
'Contact name'=>'联系人',
'Start date'=>'开始时间',
'End date'=>'结束时间',
'Person man'=>'负责人',
'LBL_CALENDAR_INFORMATION'=>'基本信息',
'Minute'=>'分钟',
'Hour'=>'小时',
'Day'=>'天',
'Swap Time' => '花费时间',
'SupplierID' => '商家',
'Description'=>'描述'
);

?>