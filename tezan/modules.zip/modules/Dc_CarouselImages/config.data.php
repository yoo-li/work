<?php

$tabid  = '6006';
$tabname  = 'Dc_CarouselImages';

$config_tabs =  array (  	 			    
					'tabname' => 'Dc_CarouselImages',
					'tablabel' => 'Dc_CarouselImages',
				    'presence' => '0',
				    'customized' => '0',
				    'isentitytype' => '1',
				    'tabsequence' => '6006',
				    'ownedby' => '0',
					);

$Config_Blocks = array (
	  1 => array (	    
	    'blocklabel' => 'LBL_BASE_INFORMATION',
	    'sequence' => '1',
	    'show_title' => '0',
	    'visible' => '0',
	    'create_view' => '0',
	    'edit_view' => '0',
	    'detail_view' => '0',
	    'display_status' => '1',
	    'iscustom' => '0',
		'columns' =>  '2',
	  ), 
);


$Config_Fields = array (
	array (
		'generatedtype' => '2',
		'uitype' => '10',
		'fieldname' => 'supplierid',
		'fieldlabel' => 'SupplierID',
		'readonly' => '1',
		'presence' => '2',
		'maximumlength' => '100',
		'sequence' => '1',
		'block' => '1',
		'displaytype' => '2',
		'typeofdata' => 'V~O',
		'info_type' => 'BAS',
		'merge_column' => '1',
		'deputy_column' => '0',
		'show_title' => '1',
		'editwidth' => '300',
		'width' => '12', // 4,8,12,20,30
		'align' => 'center', // left,center,right
	),

	array(
		'generatedtype' => '1',
		'uitype' => '1',
		'fieldname' => 'adname',
		'fieldlabel' => 'Ad Name',
		'readonly' => '0',
		'presence' => '0',
		'maximumlength' => '100',
		'sequence' => '1',
		'block' => '1',
		'displaytype' => '1',
		'typeofdata' => 'V~M',
		'info_type' => 'BAS',
		'merge_column' => '1',
		'deputy_column' => '0',
		'show_title' => '1',
		'width' => '20', // 4,8,12,20,30
		'align' => 'center', // left,center,right

	),

	array(
		'generatedtype' => '1',
		'uitype' => '33',
		'fieldname' => 'timeset',
		'fieldlabel' => 'Time Set',
		'readonly' => '0',
		'presence' => '0',
		'maximumlength' => '100',
		'sequence' => '5',
		'block' => '1',
		'displaytype' => '1',
		'typeofdata' => 'V~M',
		'info_type' => 'BAS',
		'merge_column' => '1',
		'deputy_column' => '0',
		'show_title' => '1',
		'width' => '8', // 4,8,12,20,30
		'align' => 'center', // left,center,right
	),
	array (
		'generatedtype' => '1',
		'uitype' => '5',
		'fieldname' => 'starttime',
		'fieldlabel' => 'Start Time',
		'readonly' => '0',
		'presence' => '2',
		'maximumlength' => '100',
		'sequence' => '6',
		'block' => '1',
		'displaytype' => '1',
		'typeofdata' => 'D~M',
		'info_type' => 'BAS',
		'merge_column' => '1',
		'deputy_column' => '0',
		'show_title' => '1',
		'width' => '8', // 4,8,12,20,30
		'align' => 'center', // left,center,right
	),
	array (
		'generatedtype' => '1',
		'uitype' => '5',
		'fieldname' => 'endtime',
		'fieldlabel' => 'End Time',
		'readonly' => '0',
		'presence' => '2',
		'maximumlength' => '100',
		'sequence' => '7',
		'block' => '1',
		'displaytype' => '1',
		'typeofdata' => 'D~M',
		'info_type' => 'BAS',
		'merge_column' => '1',
		'deputy_column' => '0',
		'show_title' => '1',
		'width' => '8', // 4,8,12,20,30
		'align' => 'center', // left,center,right
	),

	array(
		'generatedtype' => '1',
		'uitype' => '33',
		'fieldname' => 'status',
		'fieldlabel' => 'Use Status',
		'readonly' => '0',
		'presence' => '0',
		'maximumlength' => '100',
		'sequence' => '11',
		'block' => '1',
		'displaytype' => '1',
		'typeofdata' => 'V~M',
		'info_type' => 'BAS',
		'merge_column' => '1',
		'deputy_column' => '0',
		'show_title' => '1',
		'width' => '8', // 4,8,12,20,30
		'align' => 'center', // left,center,right
	),
	array(
		'generatedtype' => '1',
		'uitype' => '7',
		'fieldname' => 'sequence',
		'fieldlabel' => 'Sequence',
		'readonly' => '0',
		'presence' => '0',
		'maximumlength' => '50',
		'sequence' => '12',
		'block' => '1',
		'displaytype' => '1',
		'typeofdata' => 'N~M',
		'info_type' => 'BAS',
		'merge_column' => '0',
		'deputy_column' => '0',
		'show_title' => '1',
		'width' => '8', // 4,8,12,20,30
		'align' => 'center', // left,center,right
	),
	array (
		'generatedtype' => '2',
		'uitype' => '307',
		'fieldname' => 'image',
		'fieldlabel' => 'AD Image',
		'readonly' => '0',
		'presence' => '0',
		'maximumlength' => '100',
		'sequence' => '13',
		'block' => '1',
		'displaytype' => '1',
		'typeofdata' => 'F~M~768~400',
		'info_type' => 'BAS',
		'merge_column' => '1',
		'deputy_column' => '0',
		'show_title' => '1',
		'editwidth' => '300',
		'width' => '12', // 4,8,12,20,30
		'align' => 'center', // left,center,right
		'unit'=>'轮播图尺寸：<font color="red">768*400px</font>',
	),
	array (
		'generatedtype' => '2',
		'uitype' => '307',
		'fieldname' => 'webimage',
		'fieldlabel' => 'Web AD Image',
		'readonly' => '0',
		'presence' => '0',
		'maximumlength' => '100',
		'sequence' => '13',
		'block' => '1',
		'displaytype' => '1',
		'typeofdata' => 'F~M~1112~228',
		'info_type' => 'BAS',
		'merge_column' => '1',
		'deputy_column' => '0',
		'show_title' => '1',
		'editwidth' => '300',
		'width' => '12', // 4,8,12,20,30
		'align' => 'center', // left,center,right
		'unit'=>'PC端 轮播图尺寸：<font color="red">1112*228px</font>',
	),
	array (
		'generatedtype' => '1',
		'uitype' => '1',
		'fieldname' => 'approvalstatus',
		'fieldlabel' => 'Approval Status',
		'readonly' => '1',
		'presence' => '0',
		'maximumlength' => '100',
		'sequence' => '44',
		'block' => '1',
		'displaytype' => '2',
		'typeofdata' => 'V~M',
		'info_type' => 'BAS',
		'merge_column' => '0',
		'deputy_column' => '0',
		'show_title' => '1',
		'width' => '12', // 4,8,12,20,30
		'align' => 'center', // left,center,right
	),
	array(
		'generatedtype' => '1',
		'uitype' => '1',
		'fieldname' => 'mall_adsstatus',
		'fieldlabel' => 'Mall_Ads Status',
		'readonly' => '0',
		'presence' => '0',
		'maximumlength' => '50',
		'sequence' => '11',
		'block' => '1',
		'displaytype' => '2',
		'typeofdata' => 'V~O',
		'info_type' => 'BAS',
		'merge_column' => '1',
		'deputy_column' => '0',
		'show_title' => '1',
		'width' => '6', // 4,8,12,20,30
		'align' => 'center', // left,center,right
	),
);


$Config_CustomViews = array (
	array (
		'viewname' => 'Default',
		'setdefault' => '1',
		'setmetrics' => '0',
		'entitytype' => 'Mall_Ads',
		'status' => '0',
		'cvcolumnlist' =>
			array ('supplierid','adname','timeset','starttime','endtime','sequence','status','f2cadlinktarget','productid','salesactivityid','newsid','mall_adsstatus','oper'),
  ), 
);



$Config_Ws_Entitys = array (
	1 =>
		array (
			'name' => 'Mall_Ads',
			'handler_path' => 'include/Webservices/VtigerModuleOperation.php',
			'handler_class' => 'VtigerModuleOperation',
			'ismodule' => '1',
		),
);

$Config_Entitynames = array (
	0 =>
		array (
			'modulename' => 'Mall_Ads',
			'tablename' => 'Mall_Ads',
			'fieldname' => 'attname',
			'entityidfield' => 'xn_id',
			'entityidcolumn' => 'xn_id',
		),
);

$config_fieldmodulerels = array (
	array (
		'fieldname' => 'supplierid',
		'module' => 'Mall_Ads',
		'relmodule' => 'Suppliers',
		'status' => '',
		'sequence' => '0',
	),
	array (
		'fieldname' => 'productid',
		'module' => 'Mall_Ads',
		'relmodule' => 'Mall_Products',
		'status' => '',
		'sequence' => '0',
	),
	array (
		'fieldname' => 'salesactivityid',
		'module' => 'Mall_Ads',
		'relmodule' => 'Mall_SalesActivitys',
		'status' => '',
		'sequence' => '0',
	),
	array (
		'fieldname' => 'newsid',
		'module' => 'Mall_Ads',
		'relmodule' => 'Supplier_News',
		'status' => '',
		'sequence' => '0',
	),
);

$config_modentity_nums = array ( );

$config_searchcolumn = array(

	array(
		'sequence' => '2',
		'columnname' => 'status',
		'fieldname' => 'status',
		'fieldlabel' => 'Use Status',
		'type' => 'text',
		'info_type' => 'BAS',
		'newline' => false,
	),
);

$config_picklists = array (
	array (
		'name' => 'timeset',
		'picklist' =>
			array(
				array (0 => '永不过期',1 => '1',2 => '0',),
				array (0 => '设定时间内有效',1 => '1',2 => '1',),
			),
	),
	array (
		'name' => 'f2cadlinktarget',
		'picklist' =>
			array(
				array (0 => '商品',1 => '0',2 => '0',),
				array (0 => '促销活动',1 => '1',2 => '1',),
				array (0 => '商城资讯',1 => '2',2 => '2',),
			),
	),

);


?>

