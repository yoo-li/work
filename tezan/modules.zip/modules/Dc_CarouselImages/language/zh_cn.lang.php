<?php 
$mod_strings = Array(
    'SupplierID'=>'商家名称',
    'LBL_BASE_INFORMATION' => '基本信息',
    'Ads No' => '编号',
    'Ad Name' => '轮播图名称',
    'Ad Location' => '轮播图位置',
    'Link' => '链接',
    'Start Time' => '投放起始时间',
    'End Time' => '投放结束时间',
    'Time Set' => '时间限制',
    'normbody' => '站内显示内容',
    'AD Image' => '广告推广图',
    'Web AD Image'  => 'PC端广告推广图',
    'Use Status' => '状态',
    'Ad Type' => '广告类型',
    'Ad Title' => '广告内容',
    'Sequence' => '排序',
    'Ad Platform' => '广告平台',
    'Ad Link'=>'链接',
    'Use Status' =>'启用',
    'Mall_Ads Status' =>'状态',
     
);
?>