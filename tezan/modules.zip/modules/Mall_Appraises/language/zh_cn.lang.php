<?php 
$mod_strings = Array(
	'LBL_BASE_INFORMATION' => '基本信息',  
	'Supplier' => '商家', 
	'Businesse ID'=>'店铺', 
    'Praise'=>'评价',
	'Remark'=>'评语',
	'Has Images'=>'图片',
	'Mall_Appraises Status'=>'状态',
	'Order ID'=>'订单',
	'UserName'=>'会员',
	'Upload'=>'图片',
	'Product'=>'商品',
);
?>