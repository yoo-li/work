<?php 
$mod_strings = Array(
	'LBL_BASE_INFORMATION' => '基本信息',  
	'Sales Activity ID' => '活动名称', 
	'Product Name' => '砍价商品', 
	'ProfileID' => '购买会员', 
	'Bargainer' => '砍价会员', 
	'Supplier' => '商城', 
);
?>