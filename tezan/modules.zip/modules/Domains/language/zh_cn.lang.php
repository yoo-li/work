<?php 
$mod_strings = Array(
	'LBL_BASE_INFORMATION' => '基本信息',
	'Domains No' => '域名ID',
	'Domain' => '域名',
	'Domain Description' => '域名描述',
	'Province' => '省份',
	'City'=> '城市',
	'Agent Name'=> '代理商',
	'Start Date'=> '代理起始日期',
	'End Date'=> '代理结束日期',
	'Status'=> '状态', 
	'Trial Datetime' => '有效日期',
);
?>