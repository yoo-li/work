<?php
include ('modules/Public/massdelete.php');
?>
