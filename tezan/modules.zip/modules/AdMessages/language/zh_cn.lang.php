<?php 
$mod_strings = Array(
    'LBL_BASE_INFORMATION' => '基本信息', 
	'To Username'=>'接收用户',
	'Message'=>'消息',
	'APPID'=>'公众号',
	'Suppliers'=>'关联商家', 
    
);
?>